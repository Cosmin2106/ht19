from random import shuffle

import cv2
import tensorflow as tf
# Just disables the warning, doesn't enable AVX/FMA
import os
import numpy as np
from keras.preprocessing import image
import imageio
from keras.preprocessing.image import ImageDataGenerator

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

DATADIR = "alphabet-test"
IMG_SIZE = 100

CATEGORIES = ["A", "B", "C", "D", "del", "E",
		  "F", "G", "H", "I", "J",
		  "K", "L", "M", "N", "nothing", "O", "P", "Q", "R", "S", "space", "T", "U", "V", "W", "X", "Y", "Z"]


def prepare(file):
	IMG_SIZE = 50
	img_array = cv2.imread(file, cv2.IMREAD_GRAYSCALE)
	new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))
	return new_array.reshape(-1, IMG_SIZE, IMG_SIZE, 1)

#def pred():
	# load json and create model
json_file = open('model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = tf.keras.models.model_from_json(loaded_model_json)
# load weights into new model
loaded_model.load_weights("model.h5")
print("Loaded model from disk")

prediction = loaded_model.predict([prepare('test5.jpeg')])

print(CATEGORIES[int(prediction[0][0])])
#print(CATEGORIES[prediction.index(max(prediction))])
#def main():
#    pred()

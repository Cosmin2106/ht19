import firebase_admin
from firebase_admin import credentials
from firebase_admin import storage
import urllib3
import datetime


# Fetch the service account key JSON file contents
cred = credentials.Certificate("google-services.json")

# Initialize the app with a service account, granting admin privileges
app = firebase_admin.initialize_app(cred, {
    'storageBucket': 'gs://cazi-img.appspot.com',
}, name='storage')

bucket = storage.bucket(app=app)
blob = bucket.blob("<your_blob_path>")

print(blob.generate_signed_url(datetime.timedelta(seconds=300), method='GET'))

filedata = urllib3.urlopen('http://i3.ytimg.com/vi/J---aiyznGQ/mqdefault.jpg')
datatowrite = filedata.read()

with open('/Users/scott/Downloads/cat2.jpg', 'wb') as f:
    f.write(datatowrite)


from firebase import firebase
firebase = firebase.FirebaseApplication('https://your_storage.firebaseio.com', None)
result = firebase.get('/users', None)
print result
{'1': 'John Doe', '2': 'Jane Doe'}